# 🚀 QUICK START GUIDE

## ⚡ Get Your Support Ticket System Running in 5 Minutes!

### 1. Install Dependencies

```bash
# Install all dependencies
npm run install:all
```

### 2. Set Up Environment

```bash
# Copy environment file
cp backend/env.example backend/.env

# Edit the .env file with your settings
# At minimum, set:
# MONGODB_URI=mongodb://localhost:27017/support_ticket_system
# JWT_SECRET=your-secret-key-here
```

### 3. Start MongoDB & Redis

```bash
# Start MongoDB (if not running)
mongod

# Start Redis (if not running)
redis-server
```

### 4. Run the Application

```bash
# Start both frontend and backend
npm run dev
```

### 5. Access Your System

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000

## 🎯 Default Login

- **Email**: admin@example.com
- **Password**: password123

## 📋 What You Get

✅ Complete ticket management system
✅ Dynamic escalation rules
✅ Department & status management
✅ OAuth/SAML authentication
✅ Admin dashboard
✅ Real-time notifications
✅ Audit logging
✅ Performance optimization

## 🔧 Troubleshooting

- Make sure MongoDB is running on port 27017
- Make sure Redis is running on port 6379
- Check that ports 3000 and 5000 are available

## 📞 Need Help?

Everything is ready to run! Just follow the steps above.
