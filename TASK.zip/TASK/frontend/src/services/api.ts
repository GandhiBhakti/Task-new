import axios, { AxiosInstance, AxiosResponse } from 'axios';
import toast from 'react-hot-toast';

// Create axios instance
const api: AxiosInstance = axios.create({
    baseURL: process.env.REACT_APP_API_URL || '/api',
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor to add auth token
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response interceptor to handle errors
api.interceptors.response.use(
    (response: AxiosResponse) => {
        return response;
    },
    (error) => {
        if (error.response?.status === 401) {
            localStorage.removeItem('token');
            window.location.href = '/login';
        } else if (error.response?.status === 403) {
            toast.error('Access denied. You do not have permission to perform this action.');
        } else if (error.response?.status >= 500) {
            toast.error('Server error. Please try again later.');
        } else if (error.response?.data?.message) {
            toast.error(error.response.data.message);
        } else if (error.message) {
            toast.error(error.message);
        }
        return Promise.reject(error);
    }
);

// Auth API
export const authAPI = {
    login: (email: string, password: string) =>
        api.post('/auth/login', { email, password }),

    register: (data: { email: string; name: string; password: string; role?: string }) =>
        api.post('/auth/register', data),

    getMe: () =>
        api.get('/auth/me'),

    updateProfile: (data: { name?: string; email?: string }) =>
        api.put('/auth/profile', data),

    logout: () =>
        api.post('/auth/logout'),
};

// Tickets API
export const ticketsAPI = {
    getTickets: (params?: any) =>
        api.get('/tickets', { params }),

    getTicket: (id: string) =>
        api.get(`/tickets/${id}`),

    createTicket: (data: any) =>
        api.post('/tickets', data),

    updateTicket: (id: string, data: any) =>
        api.put(`/tickets/${id}`, data),

    addReply: (id: string, data: any) =>
        api.post(`/tickets/${id}/replies`, data),

    mergeTickets: (id: string, targetTicketId: string) =>
        api.post(`/tickets/${id}/merge`, { targetTicketId }),

    closeTicket: (id: string) =>
        api.post(`/tickets/${id}/close`),

    getAuditLog: (id: string) =>
        api.get(`/tickets/${id}/audit`),
};

// Departments API
export const departmentsAPI = {
    getDepartments: (params?: any) =>
        api.get('/departments', { params }),

    getDepartment: (id: string) =>
        api.get(`/departments/${id}`),

    createDepartment: (data: any) =>
        api.post('/departments', data),

    updateDepartment: (id: string, data: any) =>
        api.put(`/departments/${id}`, data),

    deleteDepartment: (id: string) =>
        api.delete(`/departments/${id}`),

    getDepartmentTickets: (id: string, params?: any) =>
        api.get(`/departments/${id}/tickets`, { params }),

    getDepartmentStats: (id: string) =>
        api.get(`/departments/${id}/statistics`),
};

// Statuses API
export const statusesAPI = {
    getStatuses: (params?: any) =>
        api.get('/statuses', { params }),

    getStatus: (id: string) =>
        api.get(`/statuses/${id}`),

    createStatus: (data: any) =>
        api.post('/statuses', data),

    updateStatus: (id: string, data: any) =>
        api.put(`/statuses/${id}`, data),

    deleteStatus: (id: string) =>
        api.delete(`/statuses/${id}`),

    getStatusTickets: (id: string, params?: any) =>
        api.get(`/statuses/${id}/tickets`, { params }),

    getStatusStats: (id: string) =>
        api.get(`/statuses/${id}/statistics`),
};

// Escalation Rules API
export const escalationRulesAPI = {
    getEscalationRules: (params?: any) =>
        api.get('/escalations', { params }),

    getEscalationRule: (id: string) =>
        api.get(`/escalations/${id}`),

    createEscalationRule: (data: any) =>
        api.post('/escalations', data),

    updateEscalationRule: (id: string, data: any) =>
        api.put(`/escalations/${id}`, data),

    deleteEscalationRule: (id: string) =>
        api.delete(`/escalations/${id}`),

    testEscalationRule: (id: string, ticketId: string) =>
        api.post(`/escalations/${id}/test`, { ticketId }),

    executeEscalationRule: (id: string, ticketId: string) =>
        api.post(`/escalations/${id}/execute`, { ticketId }),

    getEscalationRuleStats: (id: string) =>
        api.get(`/escalations/${id}/statistics`),
};

// Admin API
export const adminAPI = {
    getDashboard: () =>
        api.get('/admin/dashboard'),

    getOverview: () =>
        api.get('/admin/overview'),

    getActivity: (params?: any) =>
        api.get('/admin/activity', { params }),

    getHealth: () =>
        api.get('/admin/health'),

    getUserStats: () =>
        api.get('/admin/users/stats'),

    getTicketStats: () =>
        api.get('/admin/tickets/stats'),

    exportData: (type: string, format?: string) =>
        api.get('/admin/export', {
            params: { type, format },
            responseType: format === 'csv' ? 'blob' : 'json'
        }),
};

// Users API
export const usersAPI = {
    getUsers: (params?: any) =>
        api.get('/auth/users', { params }),
};

export default api;
