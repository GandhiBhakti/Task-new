import React from 'react';
import { useQuery } from 'react-query';
import { adminAPI } from '../services/api';
import { DashboardStats } from '../types';
import { 
    TicketIcon,
    ClockIcon,
    ChartBarIcon,
} from '@heroicons/react/24/outline';
import { 
    CheckCircleIcon,
    ExclamationTriangleIcon as ExclamationIcon,
    UserGroupIcon as UsersIcon,
} from '@heroicons/react/24/solid';

const Dashboard: React.FC = () => {
    const { data: dashboardData, isLoading, error } = useQuery({
        queryKey: ['dashboard'],
        queryFn: () => adminAPI.getDashboard(),
        select: (response) => response.data.data.stats as DashboardStats,
    });

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <div className="spinner"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="text-center py-12">
                <p className="text-red-600">Failed to load dashboard data</p>
            </div>
        );
    }

    const stats = dashboardData;

    const statCards = [
        {
            name: 'Total Tickets',
            value: stats?.totalTickets || 0,
            icon: TicketIcon,
            color: 'bg-blue-500',
        },
        {
            name: 'Open Tickets',
            value: stats?.openTickets || 0,
            icon: ClockIcon,
            color: 'bg-yellow-500',
        },
        {
            name: 'Closed Tickets',
            value: stats?.closedTickets || 0,
            icon: CheckCircleIcon,
            color: 'bg-green-500',
        },
        {
            name: 'Escalated Tickets',
            value: stats?.escalatedTickets || 0,
            icon: ExclamationIcon,
            color: 'bg-red-500',
        },
    ];

    const priorityColors: Record<Priority, string> = {
        Low: 'bg-green-100 text-green-800',
        Medium: 'bg-yellow-100 text-yellow-800',
        High: 'bg-orange-100 text-orange-800',
        Critical: 'bg-red-100 text-red-800',
    };

    return (
        <div className="space-y-6" >
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
                <p className="mt-1 text-sm text-gray-500">
                    Overview of your support ticket system
                </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {statCards.map((stat) => (
                    <div key={stat.name} className="card">
                        <div className="card-body">
                            <div className="flex items-center">
                                <div className="flex-shrink-0">
                                    <div className={`p-3 rounded-md ${stat.color}`}>
                                        <stat.icon className="h-6 w-6 text-white" />
                                    </div>
                                </div>
                                <div className="ml-5 w-0 flex-1">
                                    <dl>
                                        <dt className="text-sm font-medium text-gray-500 truncate">
                                            {stat.name}
                                        </dt>
                                        <dd className="text-lg font-medium text-gray-900">
                                            {stat.value}
                                        </dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {/* Tickets by Priority */}
                <div className="card">
                    <div className="card-header">
                        <h3 className="text-lg font-medium text-gray-900">Tickets by Priority</h3>
                    </div>
                    <div className="card-body">
                        <div className="space-y-3">
                            {stats?.ticketsByPriority && Object.entries(stats.ticketsByPriority).map(([priority, count]) => (
                                <div key={priority} className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <span className={`badge ${priorityColors[priority as keyof typeof priorityColors]}`}>
                                            {priority}
                                        </span>
                                    </div>
                                    <span className="text-sm font-medium text-gray-900">{count}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Tickets by Status */}
                <div className="card">
                    <div className="card-header">
                        <h3 className="text-lg font-medium text-gray-900">Tickets by Status</h3>
                    </div>
                    <div className="card-body">
                        <div className="space-y-3">
                            {stats?.ticketsByStatus?.map((item) => (
                                <div key={item.status} className="flex items-center justify-between">
                                    <span className="text-sm text-gray-600">{item.status}</span>
                                    <span className="text-sm font-medium text-gray-900">{item.count}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Recent Activity */}
            <div className="card">
                <div className="card-header">
                    <h3 className="text-lg font-medium text-gray-900">Recent Activity</h3>
                </div>
                <div className="card-body">
                    <div className="flow-root">
                        <ul className="-mb-8">
                            {stats?.recentActivity?.map((activity, index) => (
                                <li key={index}>
                                    <div className="relative pb-8">
                                        {index !== (stats.recentActivity?.length || 0) - 1 && (
                                            <span
                                                className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200"
                                                aria-hidden="true"
                                            />
                                        )}
                                        <div className="relative flex space-x-3">
                                            <div>
                                                <span className="h-8 w-8 rounded-full bg-primary-500 flex items-center justify-center ring-8 ring-white">
                                                    <ChartBarIcon className="h-5 w-5 text-white" />
                                                </span>
                                            </div>
                                            <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                                                <div>
                                                    <p className="text-sm text-gray-500">
                                                        <span className="font-medium text-gray-900">{activity.user}</span>{' '}
                                                        {activity.action} ticket{' '}
                                                        <span className="font-medium text-gray-900">{activity.ticket}</span>
                                                    </p>
                                                </div>
                                                <div className="text-right text-sm whitespace-nowrap text-gray-500">
                                                    {new Date(activity.timestamp).toLocaleDateString()}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
