import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ticketsAPI } from "../services/api";
import {
  PlusIcon,
  MagnifyingGlassIcon as SearchIcon,
  FunnelIcon as FilterIcon,
} from "@heroicons/react/24/outline";

interface TicketStatus {
  id: string;
  title: string;
}

interface TicketDepartment {
  id: string;
  name: string;
}

interface TicketUser {
  id: string;
  name: string;
}

interface TicketBase {
  id: string;
  ticketNumber: string;
  title: string;
  description?: string;
  priority: string;
  createdAt: string;
  updatedAt: string;
}

interface TicketWithRelations extends TicketBase {
  status: TicketStatus | null;
  department: TicketDepartment | null;
  assignedTo: TicketUser | null;
}

interface Pagination {
  total: number;
  pages: number;
  page: number;
  limit: number;
}

interface TicketsResponse {
  tickets: TicketWithRelations[];
  pagination: Pagination;
}

interface TicketFilters {
  search: string;
  status: string;
  department: string;
  assignedTo: string;
  priority: string;
  page: number;
  limit: number;
}

const priorityColors: Record<string, string> = {
  High: "bg-red-100 text-red-800",
  Medium: "bg-yellow-100 text-yellow-800",
  Low: "bg-green-100 text-green-800",
};

type PriorityType = keyof typeof priorityColors;
const isPriority = (priority: string): priority is PriorityType =>
  priority in priorityColors;

const statusColors: Record<string, string> = {
  Open: "bg-green-100 text-green-800",
  "In Progress": "bg-blue-100 text-blue-800",
  Closed: "bg-gray-100 text-gray-800",
};

type StatusType = keyof typeof statusColors;
const isStatus = (status: string): status is StatusType =>
  status in statusColors;

export default function Tickets() {
  const [filters, setFilters] = useState<TicketFilters>({
    search: "",
    status: "",
    department: "",
    assignedTo: "",
    priority: "",
    page: 1,
    limit: 10,
  });

  const {
    data: ticketsData,
    isLoading,
    error,
  } = useQuery<TicketsResponse, Error>({
    queryKey: ["tickets", filters],
    queryFn: async () => {
      const response = await ticketsAPI.getTickets(filters);
      return response.data;
    },
  });

  if (isLoading) {
    return <div>Loading tickets...</div>;
  }

  if (error) {
    const errorMessage =
      (error as Error).message ?? "Failed to load tickets";
    return <div className="text-red-500">{errorMessage}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Tickets</h1>
        <Link
          to="/tickets/new"
          className="btn btn-primary flex items-center gap-2"
        >
          <PlusIcon className="h-5 w-5" />
          Create Ticket
        </Link>
      </div>

      <div className="bg-white p-4 rounded-lg shadow space-y-4">
        <div className="flex gap-4">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Search tickets..."
              value={filters.search}
              onChange={(e) =>
                setFilters({ ...filters, search: e.target.value })
              }
              className="input pl-10"
            />
            <SearchIcon className="h-5 w-5 absolute left-3 top-2.5 text-gray-400" />
          </div>
          <button className="btn btn-secondary flex items-center gap-2">
            <FilterIcon className="h-5 w-5" />
            Filters
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Ticket Number
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Title
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Department
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Priority
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Assigned To
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Created At
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {ticketsData?.tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Link
                    to={`/tickets/${ticket.id}`}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    {ticket.ticketNumber}
                  </Link>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{ticket.title}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {ticket.department?.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {ticket.status?.title && isStatus(ticket.status.title) ? (
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[ticket.status.title]}`}
                    >
                      {ticket.status.title}
                    </span>
                  ) : (
                    ticket.status?.title
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {isPriority(ticket.priority) ? (
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${priorityColors[ticket.priority]}`}
                    >
                      {ticket.priority}
                    </span>
                  ) : (
                    ticket.priority
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {ticket.assignedTo?.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(ticket.createdAt).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="p-4 flex justify-between items-center">
          <p className="text-sm text-gray-500">
            Showing page {filters.page} of{" "}
            {ticketsData?.pagination.pages ?? 1}
          </p>
          <div className="flex space-x-2">
            <button
              onClick={() =>
                setFilters({ ...filters, page: filters.page - 1 })
              }
              disabled={filters.page === 1}
              className="btn btn-secondary btn-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <button
              onClick={() =>
                setFilters({ ...filters, page: filters.page + 1 })
              }
              disabled={
                filters.page >= (ticketsData?.pagination.pages ?? 1)
              }
              className="btn btn-secondary btn-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
