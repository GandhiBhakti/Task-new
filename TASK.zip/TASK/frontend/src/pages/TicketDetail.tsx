import React from 'react';
import { useParams } from 'react-router-dom';

const TicketDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Ticket Detail</h1>
                <p className="mt-1 text-sm text-gray-500">
                    Ticket ID: {id}
                </p>
            </div>

            <div className="card">
                <div className="card-body">
                    <p className="text-gray-600">Ticket detail page implementation coming soon...</p>
                </div>
            </div>
        </div>
    );
};

export default TicketDetail;
