// User Types
export interface User {
    id: string;
    email: string;
    name: string;
    role: 'admin' | 'agent' | 'user';
    department?: Department;
    isActive: boolean;
    lastLogin?: string;
    createdAt: string;
    updatedAt: string;
}

// Department Types
export interface Department {
    id: string;
    name: string;
    description: string;
    email: string;
    assignedAdmins: User[];
    isHidden: boolean;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}

// Status Types
export interface Status {
    id: string;
    title: string;
    color: string;
    includeInActiveTickets: boolean;
    autoClose?: number;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}

// Priority Types
export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

// Attachment Types
export interface Attachment {
    id: string;
    filename: string;
    originalName: string;
    mimetype: string;
    size: number;
    path: string;
    uploadedBy: User;
    uploadedAt: string;
}

// Ticket Types
export interface Ticket {
    id: string;
    ticketNumber: string;
    title: string;
    description: string;
    priority: Priority;
    status: Status;
    department: Department;
    assignedTo?: User;
    createdBy: User;
    tags: string[];
    attachments: Attachment[];
    dependencies: Ticket[];
    parentTicket?: Ticket;
    mergedTickets: Ticket[];
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
    closedAt?: string;
}

// Reply Types
export interface Reply {
    id: string;
    ticket: string;
    message: string;
    author: User;
    isInternal: boolean;
    attachments: Attachment[];
    createdAt: string;
    updatedAt: string;
}

// Escalation Rule Types
export interface EscalationCondition {
    field: 'department' | 'status' | 'priority' | 'timeElapsed';
    operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains';
    value: string | number;
    logicalOperator?: 'AND' | 'OR';
}

export interface EscalationAction {
    type: 'assign_department' | 'change_status' | 'update_priority' | 'assign_user' | 'add_reply';
    value: string;
    message?: string;
}

export interface EscalationRule {
    id: string;
    name: string;
    description?: string;
    conditions: EscalationCondition[];
    actions: EscalationAction[];
    isActive: boolean;
    priority: number;
    createdAt: string;
    updatedAt: string;
}

// Audit Log Types
export interface AuditLog {
    id: string;
    ticket: Ticket;
    action: string;
    performedBy: User;
    oldValue?: any;
    newValue?: any;
    timestamp: string;
    ipAddress?: string;
    userAgent?: string;
}

// Notification Types
export interface Notification {
    id: string;
    recipient: string;
    type: 'ticket_created' | 'ticket_updated' | 'ticket_assigned' | 'escalation' | 'reminder';
    title: string;
    message: string;
    ticket?: Ticket;
    isRead: boolean;
    createdAt: string;
}

// API Response Types
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    message?: string;
    error?: string;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        pages: number;
    };
}

// Filter Types
export interface TicketFilters {
    status?: string;
    priority?: Priority;
    department?: string;
    assignedTo?: string;
    createdBy?: string;
    tags?: string[];
    dateFrom?: Date;
    dateTo?: Date;
    search?: string;
}

// Pagination Types
export interface PaginationOptions {
    page: number;
    limit: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
}

// Dashboard Stats Types
export interface DashboardStats {
    totalTickets: number;
    openTickets: number;
    closedTickets: number;
    escalatedTickets: number;
    ticketsByPriority: Record<Priority, number>;
    ticketsByStatus: Array<{ status: string; count: number }>;
    ticketsByDepartment: Array<{ department: string; count: number }>;
    averageResolutionTime: number;
    recentActivity: Array<{
        action: string;
        ticket: string;
        user: string;
        timestamp: string;
    }>;
}

// Form Types
export interface CreateTicketForm {
    title: string;
    description: string;
    priority: Priority;
    department: string;
    tags: string[];
}

export interface CreateDepartmentForm {
    name: string;
    description: string;
    email: string;
    assignedAdmins: string[];
    isHidden: boolean;
}

export interface CreateStatusForm {
    title: string;
    color: string;
    includeInActiveTickets: boolean;
    autoClose?: number;
}

export interface CreateEscalationRuleForm {
    name: string;
    description?: string;
    conditions: EscalationCondition[];
    actions: EscalationAction[];
    priority: number;
}

export interface ReplyForm {
    message: string;
    isInternal: boolean;
}

// Auth Types
export interface LoginForm {
    email: string;
    password: string;
}

export interface AuthContextType {
    user: User | null;
    login: (email: string, password: string) => Promise<void>;
    logout: () => void;
    isLoading: boolean;
    isAuthenticated: boolean;
}

// Component Props Types
export interface TableColumn<T> {
    key: keyof T;
    label: string;
    sortable?: boolean;
    render?: (value: any, item: T) => React.ReactNode;
}

export interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
    size?: 'sm' | 'md' | 'lg' | 'xl';
}

export interface ConfirmDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    type?: 'danger' | 'warning' | 'info';
}
