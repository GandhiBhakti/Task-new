import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { authAPI } from '../services/api';
import { User, AuthContextType, LoginForm } from '../types';
import toast from 'react-hot-toast';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
    children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    // Check if user is authenticated
    const isAuthenticated = !!user;

    // Initialize auth state
    useEffect(() => {
        const initAuth = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                try {
                    const response = await authAPI.getMe();
                    if (response.data.success) {
                        setUser(response.data.data.user);
                    } else {
                        localStorage.removeItem('token');
                    }
                } catch (error) {
                    localStorage.removeItem('token');
                }
            }
            setIsLoading(false);
        };

        initAuth();
    }, []);

    // Login function
    const login = async (email: string, password: string): Promise<void> => {
        try {
            const response = await authAPI.login(email, password);
            if (response.data.success) {
                const { user: userData, token } = response.data.data;
                localStorage.setItem('token', token);
                setUser(userData);
                toast.success('Login successful!');
            } else {
                throw new Error(response.data.message || 'Login failed');
            }
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || 'Login failed';
            toast.error(message);
            throw error;
        }
    };

    // Logout function
    const logout = async (): Promise<void> => {
        try {
            await authAPI.logout();
        } catch (error) {
            // Ignore logout errors
        } finally {
            localStorage.removeItem('token');
            setUser(null);
            toast.success('Logged out successfully');
        }
    };

    // Update user profile
    const updateProfile = async (data: { name?: string; email?: string }): Promise<void> => {
        try {
            const response = await authAPI.updateProfile(data);
            if (response.data.success) {
                setUser(response.data.data.user);
                toast.success('Profile updated successfully!');
            } else {
                throw new Error(response.data.message || 'Profile update failed');
            }
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || 'Profile update failed';
            toast.error(message);
            throw error;
        }
    };

    const value: AuthContextType = {
        user,
        login,
        logout,
        isLoading,
        isAuthenticated,
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

// Custom hook to use auth context
export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

// Higher-order component for protected routes
interface ProtectedRouteProps {
    children: ReactNode;
    requiredRole?: 'admin' | 'agent' | 'user';
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
    children,
    requiredRole
}) => {
    const { user, isLoading } = useAuth();

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <div className="spinner mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading...</p>
                </div>
            </div>
        );
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (requiredRole && user.role !== requiredRole && user.role !== 'admin') {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
                    <p className="text-gray-600">You do not have permission to access this page.</p>
                </div>
            </div>
        );
    }

    return <>{children}</>;
};

