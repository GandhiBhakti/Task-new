import React, { ReactNode } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { Tickets } from './pages/Tickets';
import { TicketDetail } from './pages/TicketDetail';
import { CreateTicket } from './pages/CreateTicket';
import { Departments } from './pages/Departments';
import { Statuses } from './pages/Statuses';
import { EscalationRules } from './pages/EscalationRules';
import { AdminDashboard } from './pages/AdminDashboard';
import { Profile } from './pages/Profile';
import { NotFound } from './pages/NotFound';

type UserRole = 'admin' | 'agent' | 'user';

interface ProtectedRouteWrapperProps {
  children: ReactNode;
  requiredRole?: UserRole;
}

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {/* Protected Routes */}
        <Route element={<Layout />}>
          <Route path="/" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
          
          <Route path="/tickets" element={
            <ProtectedRoute>
              <Tickets />
            </ProtectedRoute>
          } />
          
          <Route path="/tickets/:id" element={
            <ProtectedRoute>
              <TicketDetail />
            </ProtectedRoute>
          } />
          
          <Route path="/create-ticket" element={
            <ProtectedRoute>
              <CreateTicket />
            </ProtectedRoute>
          } />
          
          <Route path="/departments" element={
            <ProtectedRoute requiredRole="admin">
              <Departments />
            </ProtectedRoute>
          } />
          
          <Route path="/statuses" element={
            <ProtectedRoute requiredRole="admin">
              <Statuses />
            </ProtectedRoute>
          } />
          
          <Route path="/escalation-rules" element={
            <ProtectedRoute requiredRole="admin">
              <EscalationRules />
            </ProtectedRoute>
          } />
          
          <Route path="/admin" element={
            <ProtectedRoute requiredRole="admin">
              <AdminDashboard />
            </ProtectedRoute>
          } />
          
          <Route path="/profile" element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } />
        </Route>
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AuthProvider>
  );
};

export default App;
