# Support Ticket System

A sophisticated support ticket system featuring dynamic escalation rules, customizable support departments, flexible status management, and secure admin login via OAuth/SAML.

## Features

### 🔐 Authentication & Authorization
- **OAuth/SAML Integration**: Secure admin authentication with Google OAuth and SAML
- **Role-based Access Control**: Admin, Agent, and User roles with different permissions
- **JWT Token Management**: Secure token-based authentication

### 🎫 Ticket Management
- **Ticket Creation**: Create tickets with title, description, priority, department, and tags
- **Status Tracking**: Dynamic status management (Open, In Progress, Escalated, Merged, Closed)
- **Ticket Assignment**: Manual and automatic ticket assignment to support agents
- **Ticket Dependencies**: Link tickets with dependencies to prevent premature closure
- **Ticket Merging**: Merge related tickets for better organization

### ⚡ Dynamic Escalation Rules
- **Rule Creation**: Create complex escalation rules with multiple conditions
- **Condition Types**: Department, Status, Priority, and Time-based conditions
- **Action Types**: Assign department, change status, update priority, assign user, add reply
- **Logical Operators**: Combine conditions with AND/OR logic
- **Priority-based Execution**: Rules execute based on priority levels

### 🏢 Dynamic Support Departments
- **Department Management**: Create, edit, and delete departments dynamically
- **Admin Assignment**: Assign multiple admins to each department
- **Hidden Departments**: Internal-only departments not visible to clients
- **Email Integration**: Department-specific email addresses for notifications

### 🏷️ Dynamic Support Statuses
- **Status Management**: Create custom statuses with colors and behaviors
- **Active Ticket Inclusion**: Control which statuses count as "active" tickets
- **Auto-close Functionality**: Automatically close tickets after specified time
- **Visual Indicators**: Color-coded statuses for easy identification

### 📊 Advanced Features
- **Audit Logging**: Complete history tracking of all ticket activities
- **Notification System**: Automated notifications and reminders
- **Performance Optimization**: Caching and background job processing
- **Concurrency Handling**: Optimistic locking for concurrent updates
- **Data Export**: Export tickets, users, and other data in JSON/CSV formats

## Technology Stack

### Backend
- **Node.js** with **Express.js** and **TypeScript**
- **MongoDB** with **Mongoose** ODM
- **Redis** for caching and session management
- **Passport.js** for authentication (JWT, OAuth, SAML)
- **Node-cron** for scheduled tasks
- **Winston** for logging
- **Express-rate-limit** for API protection

### Frontend
- **React 18** with **TypeScript**
- **React Router** for navigation
- **TanStack Query** for data fetching and caching
- **React Hook Form** for form management
- **Tailwind CSS** for styling
- **Heroicons** for icons
- **React Hot Toast** for notifications

## Project Structure

```
support-ticket-system/
├── backend/
│   ├── src/
│   │   ├── config/          # Configuration files
│   │   ├── middleware/      # Express middleware
│   │   ├── models/          # MongoDB models
│   │   ├── routes/          # API routes
│   │   ├── services/        # Business logic services
│   │   ├── types/           # TypeScript type definitions
│   │   ├── utils/           # Utility functions
│   │   └── server.ts        # Main server file
│   ├── package.json
│   └── tsconfig.json
├── frontend/
│   ├── src/
│   │   ├── components/      # Reusable React components
│   │   ├── contexts/        # React contexts
│   │   ├── pages/           # Page components
│   │   ├── services/        # API service functions
│   │   ├── types/           # TypeScript type definitions
│   │   ├── utils/           # Utility functions
│   │   ├── App.tsx
│   │   └── index.tsx
│   ├── package.json
│   └── tailwind.config.js
├── package.json
└── README.md
```

## Installation & Setup

### Prerequisites
- Node.js (v18 or higher)
- MongoDB (v5 or higher)
- Redis (v6 or higher)
- npm or yarn

### Backend Setup

1. **Navigate to backend directory**:
   ```bash
   cd backend
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Environment Configuration**:
   ```bash
   cp env.example .env
   ```
   
   Update the `.env` file with your configuration:
   ```env
   # Server Configuration
   PORT=5000
   NODE_ENV=development
   
   # Database Configuration
   MONGODB_URI=mongodb://localhost:27017/support_ticket_system
   REDIS_URL=redis://localhost:6379
   
   # JWT Configuration
   JWT_SECRET=your-super-secret-jwt-key-here
   JWT_EXPIRES_IN=7d
   
   # OAuth Configuration
   GOOGLE_CLIENT_ID=your-google-client-id
   GOOGLE_CLIENT_SECRET=your-google-client-secret
   GOOGLE_CALLBACK_URL=http://localhost:5000/api/auth/google/callback
   
   # SAML Configuration
   SAML_ENTRY_POINT=https://your-saml-provider.com/sso
   SAML_ISSUER=your-app-issuer
   SAML_CALLBACK_URL=http://localhost:5000/api/auth/saml/callback
   SAML_CERT=your-saml-certificate
   
   # Email Configuration
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-app-password
   FROM_EMAIL=noreply@yourcompany.com
   
   # CORS Configuration
   FRONTEND_URL=http://localhost:3000
   ```

4. **Start the backend server**:
   ```bash
   npm run dev
   ```

### Frontend Setup

1. **Navigate to frontend directory**:
   ```bash
   cd frontend
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start the frontend development server**:
   ```bash
   npm start
   ```

### Full Stack Development

From the root directory, you can run both frontend and backend simultaneously:

```bash
npm run dev
```

## API Documentation

### Authentication Endpoints

- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/profile` - Update user profile
- `POST /api/auth/logout` - User logout
- `GET /api/auth/google` - Google OAuth login
- `GET /api/auth/saml` - SAML login

### Ticket Endpoints

- `GET /api/tickets` - Get all tickets (with filtering and pagination)
- `GET /api/tickets/:id` - Get single ticket
- `POST /api/tickets` - Create new ticket
- `PUT /api/tickets/:id` - Update ticket
- `POST /api/tickets/:id/replies` - Add reply to ticket
- `POST /api/tickets/:id/merge` - Merge tickets
- `POST /api/tickets/:id/close` - Close ticket
- `GET /api/tickets/:id/audit` - Get ticket audit log

### Department Endpoints

- `GET /api/departments` - Get all departments
- `GET /api/departments/:id` - Get single department
- `POST /api/departments` - Create new department
- `PUT /api/departments/:id` - Update department
- `DELETE /api/departments/:id` - Delete department
- `GET /api/departments/:id/tickets` - Get department tickets
- `GET /api/departments/:id/statistics` - Get department statistics

### Status Endpoints

- `GET /api/statuses` - Get all statuses
- `GET /api/statuses/:id` - Get single status
- `POST /api/statuses` - Create new status
- `PUT /api/statuses/:id` - Update status
- `DELETE /api/statuses/:id` - Delete status
- `GET /api/statuses/:id/tickets` - Get status tickets
- `GET /api/statuses/:id/statistics` - Get status statistics

### Escalation Rule Endpoints

- `GET /api/escalations` - Get all escalation rules
- `GET /api/escalations/:id` - Get single escalation rule
- `POST /api/escalations` - Create new escalation rule
- `PUT /api/escalations/:id` - Update escalation rule
- `DELETE /api/escalations/:id` - Delete escalation rule
- `POST /api/escalations/:id/test` - Test escalation rule
- `POST /api/escalations/:id/execute` - Execute escalation rule manually

### Admin Endpoints

- `GET /api/admin/dashboard` - Get dashboard statistics
- `GET /api/admin/overview` - Get system overview
- `GET /api/admin/activity` - Get recent activity
- `GET /api/admin/health` - Get system health
- `GET /api/admin/users/stats` - Get user statistics
- `GET /api/admin/tickets/stats` - Get ticket statistics
- `GET /api/admin/export` - Export data

## Database Schema

### Users Collection
```typescript
{
  _id: ObjectId,
  email: string,
  name: string,
  role: 'admin' | 'agent' | 'user',
  department?: ObjectId,
  isActive: boolean,
  lastLogin?: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Tickets Collection
```typescript
{
  _id: ObjectId,
  ticketNumber: string,
  title: string,
  description: string,
  priority: 'Low' | 'Medium' | 'High' | 'Critical',
  status: ObjectId,
  department: ObjectId,
  assignedTo?: ObjectId,
  createdBy: ObjectId,
  tags: string[],
  attachments: Attachment[],
  dependencies: ObjectId[],
  parentTicket?: ObjectId,
  mergedTickets: ObjectId[],
  isActive: boolean,
  createdAt: Date,
  updatedAt: Date,
  closedAt?: Date
}
```

### Departments Collection
```typescript
{
  _id: ObjectId,
  name: string,
  description: string,
  email: string,
  assignedAdmins: ObjectId[],
  isHidden: boolean,
  isActive: boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### Statuses Collection
```typescript
{
  _id: ObjectId,
  title: string,
  color: string,
  includeInActiveTickets: boolean,
  autoClose?: number,
  isActive: boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### Escalation Rules Collection
```typescript
{
  _id: ObjectId,
  name: string,
  description?: string,
  conditions: EscalationCondition[],
  actions: EscalationAction[],
  isActive: boolean,
  priority: number,
  createdAt: Date,
  updatedAt: Date
}
```

## Key Features Implementation

### Dynamic Escalation Rules
The system supports complex escalation rules with multiple conditions and actions:

```typescript
// Example escalation rule
{
  name: "High Priority Timeout",
  conditions: [
    {
      field: "priority",
      operator: "equals",
      value: "High"
    },
    {
      field: "timeElapsed",
      operator: "greater_than",
      value: 60, // minutes
      logicalOperator: "AND"
    }
  ],
  actions: [
    {
      type: "change_status",
      value: "escalated_status_id"
    },
    {
      type: "assign_user",
      value: "admin_user_id"
    },
    {
      type: "add_reply",
      message: "Ticket escalated due to high priority timeout"
    }
  ]
}
```

### Ticket Dependencies
Tickets can have dependencies to prevent premature closure:

```typescript
// Ticket with dependencies
{
  ticketNumber: "TKT-2024-000001",
  title: "Bug Fix",
  dependencies: ["parent_ticket_id"],
  // ... other fields
}
```

### Automated Notifications
The system sends automated notifications based on:
- Ticket creation and updates
- Escalation rule execution
- Time-based reminders
- Status changes

### Performance Optimization
- **Caching**: Redis caching for frequently accessed data
- **Background Jobs**: Cron jobs for escalations and notifications
- **Database Indexing**: Optimized MongoDB indexes
- **Pagination**: Efficient pagination for large datasets

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **OAuth/SAML Integration**: Enterprise-grade authentication
- **Rate Limiting**: API rate limiting to prevent abuse
- **Input Validation**: Comprehensive input validation and sanitization
- **CORS Protection**: Configurable CORS settings
- **Helmet Security**: Security headers with Helmet.js
- **Audit Logging**: Complete audit trail of all actions

## Deployment

### Production Environment Variables
```env
NODE_ENV=production
MONGODB_URI=mongodb://your-production-mongodb-uri
REDIS_URL=redis://your-production-redis-uri
JWT_SECRET=your-production-jwt-secret
FRONTEND_URL=https://your-production-frontend-url
```

### Docker Deployment (Optional)
```dockerfile
# Backend Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]
```

### Environment Setup
1. Set up MongoDB cluster
2. Set up Redis instance
3. Configure OAuth/SAML providers
4. Set up email service (SMTP)
5. Deploy backend to your preferred platform
6. Deploy frontend to CDN or static hosting

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions, please contact:
- **Company**: SharkStriker Private Limited
- **Address**: 615 Binori Bsquare III, Sindhu Bhavan Road, Bodakdev, Ahmedabad 380054, INDIA
- **Website**: www.sharkstriker.com
- **Email**: hr@sharkstriker.com

## Roadmap

### Phase 1 (Completed)
- ✅ Basic ticket management
- ✅ User authentication and authorization
- ✅ Department and status management
- ✅ Escalation rules system
- ✅ Audit logging
- ✅ Basic frontend interface

### Phase 2 (Planned)
- 🔄 Advanced ticket filtering and search
- 🔄 File attachment system
- 🔄 Email notifications
- 🔄 Advanced reporting and analytics
- 🔄 Mobile responsive design
- 🔄 API documentation with Swagger

### Phase 3 (Future)
- 📋 Advanced workflow automation
- 📋 Integration with external systems
- 📋 Advanced analytics dashboard
- 📋 Multi-language support
- 📋 Advanced security features
- 📋 Performance monitoring

---

**Built with ❤️ by SharkStriker Private Limited**
